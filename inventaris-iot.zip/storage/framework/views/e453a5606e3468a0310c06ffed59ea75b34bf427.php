<a href="#">
    <img src="<?php echo e(asset('startbootstrap/img/logo.png')); ?>" alt="Logo IoT Lab Jasamarga">
</a>
<?php /**PATH C:\xamppp\htdocs\Laravel\inventaris-iot\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>