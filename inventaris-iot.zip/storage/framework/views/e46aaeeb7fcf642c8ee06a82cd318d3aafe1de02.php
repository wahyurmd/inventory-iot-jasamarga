

<?php $__env->startSection('body'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
    
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Inventory Data</h1>
    <p class="mb-4">Inventory list at Jasamarga IoT Laboratory.</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="d-sm-flex card-header py-3 justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Inventory Data Table</h6>
            <a href="#" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addInventoryModal"><i class="fas fa-fw fa-plus"></i> Add Inventory</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered display nowrap" id="inventorytable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Inventory Code</th>
                            <th>Inventory Picture</th>
                            <th>Inventory Name</th>
                            <th>Room</th>
                            <th>Added By</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->inventory_code); ?></td>
                            <td>
                                <img class="img-fluid" src="<?php echo e(asset('storage/images/' . $row->inventory_picture)); ?>" alt="<?php echo e($row->inventory_name); ?>">
                            </td>
                            <td><?php echo e($row->inventory_name); ?></td>
                            <td><?php echo e($row->room); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->created_at); ?></td>
                            <td>
                                <div class="row justify-content-center">
                                    <a href="#" class="btn btn-primary btn-sm mr-1" data-toggle="modal" data-target="#detailInventoryModal<?php echo e($row->id); ?>"><i class="fas fa-fw fa-eye"></i></a>
                                    <a href="#" class="btn btn-info btn-sm" data-toggle="modal" data-target="#transferInventoryModal<?php echo e($row->id); ?>"><i class="fa-solid fa-arrow-right-arrow-left"></i></a>
                                </div>
                                <div class="row justify-content-center mt-2">
                                    <a href="#" class="btn btn-warning btn-sm mr-1" data-toggle="modal" data-target="#editInventoryModal<?php echo e($row->id); ?>"><i class="fas fa-fw fa-edit"></i></a>
                                    <a href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteInventoryModal<?php echo e($row->id); ?>"><i class="fas fa-fw fa-trash-alt"></i></a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Inventory Modal -->
    <div class="modal fade" id="addInventoryModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Inventory</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="<?php echo e(route('inventory')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Inventory Code</label>
                            <p style="font-size: 12px; margin-top: -10px; color: rgb(255, 0, 0)"><i>If there is no Inventory Code, Click Generate!</i></p>
                            <div class="row" style="margin-top: -10px">
                                <div class="col-md-10 col-sm-10 mb-2">
                                    <input type="text" class="form-control form-control-user" name="inventory_code" id="generate" autocomplete="off" required>
                                </div>
                                <div class="col-md-2 col-sm-2">
                                    <a class="btn btn-primary" onclick="Generate()">Generate</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Inventory Name</label>
                            <input type="text" class="form-control form-control-user" name="inventory_name" autocomplete="off" required>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Inventory Picture</label>
                            <img class="img-fluid img-preview mb-3 col-sm-3">
                            <input type="file" class="form-control" name="inventory_picture" id="image" onchange="previewImage()" required>
                            <p style="font-size: 12px; color: rgb(78, 78, 78)"><i>Note: can only format .png, .jpg, and .jpeg</i></p>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Select Room</label>
                            <select name="room_id" class="form-control form-control-user" required>
                                <option value="" disabled>Choose Room</option>
                                <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->room); ?> | <?php echo e($row->location); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Description</label>
                            <input type="text" class="form-control form-control-user" name="description" autocomplete="off" required>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <input type="hidden" class="form-control form-control-user" name="user_id" id="formFile" value="<?php echo e(Auth::user()->id); ?>" required>
                            <input type="hidden" class="form-control form-control-user" name="stock_status" id="formFile" value="Available" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" onclick="addConfirm()">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- END: Add Inventory Modal -->

    <!-- Update Inventory Modal -->
    <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="editInventoryModal<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Inventory</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="inventory/edit/<?php echo e($row->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Inventory Code</label>
                            <input type="text" class="form-control form-control-user" name="inventory_code" id="generate" value="<?php echo e($row->inventory_code); ?>" autocomplete="off" required>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Inventory Name</label>
                            <input type="text" class="form-control form-control-user" name="inventory_name" autocomplete="off" value="<?php echo e($row->inventory_name); ?>" readonly>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Inventory Picture</label>
                            <br>
                            <?php if($row->inventory_picture): ?>
                                <img src="<?php echo e(asset('storage/images/' . $row->inventory_picture)); ?>" alt="<?php echo e($row->inventory_name); ?>" class="img-fluid col-sm-3 mb-3">
                            <?php endif; ?>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Room Location</label>
                            <input type="text" class="form-control form-control-user" name="room_id" autocomplete="off" value="<?php echo e($row->room); ?> | <?php echo e($row->location); ?>" readonly>
                        </div>
                        <div class="col-sm-12 mb-3">
                            <label class="control-label">Description</label>
                            <input type="text" class="form-control form-control-user" name="description" autocomplete="off" value="<?php echo e($row->description); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" onclick="editConfirm(<?php echo e($row->id); ?>)">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END: Update Inventory Modal -->

    <!-- Detail Inventory Modal-->
    <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="detailInventoryModal<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detail Inventory</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="col-sm-12 mb-3 row">
                        <div class="col-sm-3">
                            <label>Inventory Code</label>
                        </div>
                        <div class="col-sm-1">
                            <label>:</label>
                        </div>
                        <div class="col-sm-8">
                            <label><?php echo e($row->inventory_code); ?></label>
                        </div>
                    </div>
                    <div class="col-sm-12 mb-3 row">
                        <div class="col-sm-3">
                            <label>Inventory Name</label>
                        </div>
                        <div class="col-sm-1">
                            <label>:</label>
                        </div>
                        <div class="col-sm-8">
                            <label><?php echo e($row->inventory_name); ?></label>
                        </div>
                    </div>
                    <div class="col-sm-12 mb-3 row">
                        <div class="col-sm-3">
                            <label>Inventory Picture</label>
                        </div>
                        <div class="col-sm-1">
                            <label>:</label>
                        </div>
                        <div class="col-sm-8">
                            <img src="<?php echo e(asset('storage/images/' . $row->inventory_picture)); ?>" alt="<?php echo e($row->inventory_name); ?>" class="img-fluid col-sm-3">
                        </div>
                    </div>
                    <div class="col-sm-12 mb-3 row">
                        <div class="col-sm-3">
                            <label>Room</label>
                        </div>
                        <div class="col-sm-1">
                            <label>:</label>
                        </div>
                        <div class="col-sm-8">
                            <label><?php echo e($row->room); ?> | <?php echo e($row->location); ?></label>
                        </div>
                    </div>
                    <div class="col-sm-12 mb-3 row">
                        <div class="col-sm-3">
                            <label>Description</label>
                        </div>
                        <div class="col-sm-1">
                            <label>:</label>
                        </div>
                        <div class="col-sm-8">
                            <label><?php echo e($row->description); ?></label>
                        </div>
                    </div>
                    <div class="col-sm-12 mb-3 row">
                        <div class="col-sm-3">
                            <label>Added By</label>
                        </div>
                        <div class="col-sm-1">
                            <label>:</label>
                        </div>
                        <div class="col-sm-8">
                            <label><?php echo e($row->name); ?></label>
                        </div>
                    </div>
                    <div class="col-sm-12 mb-3 row">
                        <div class="col-sm-3">
                            <label>Status</label>
                        </div>
                        <div class="col-sm-1">
                            <label>:</label>
                        </div>
                        <div class="col-sm-8">
                            <?php if($row->stock_status == 'Available'): ?>    
                                <span class="btn btn-success disabled" style="min-width: 150px"><?php echo e($row->stock_status); ?></span>
                            <?php endif; ?>
                            <?php if($row->stock_status == 'Not Available'): ?>    
                                <span class="btn btn-danger disabled" style="min-width: 150px"><?php echo e($row->stock_status); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-12 mb-3 row">
                        <div class="col-sm-3">
                            <label>Created At</label>
                        </div>
                        <div class="col-sm-1">
                            <label>:</label>
                        </div>
                        <div class="col-sm-8">
                            <label><?php echo e($row->created_at); ?></label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END: Detail Inventory Modal -->

    <!-- Delete Inventory Modal -->
    <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="deleteInventoryModal<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Are you sure?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="inventory/delete/<?php echo e($row->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        Select "Delete" below if you are sure.
                        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                        <input type="hidden" name="room_id" value="<?php echo e($row->room_id); ?>">
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger" onclick="deleteConfirm(<?php echo e($row->id); ?>)">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END: Delete Inventory Modal -->

    <!-- Transfer Room Inventory Modal -->
    <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="transferInventoryModal<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Transfer Room</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="inventory/transfer/<?php echo e($row->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-sm-12 mb-3">
                            <label class="control-label">Previous Room</label>
                            <input type="text" class="form-control form-control-user" name="previous_room" autocomplete="off" value="<?php echo e($row->room); ?>" readonly>
                        </div>
                    <div class="col-sm-12 mb-3">
                        <label class="control-label">Transfer to</label>
                        <select name="transfer_room_id" class="form-control form-control-user" required>
                            <option disabled>Choose Room</option>
                            <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->room); ?> | <?php echo e($data->location); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-sm-12 mb-3">
                        <input type="hidden" class="form-control form-control-user" name="inventory_id" id="formFile" value="<?php echo e($row->id); ?>">
                        <input type="hidden" class="form-control form-control-user" name="user_id" id="formFile" value="<?php echo e(Auth::user()->id); ?>">
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" onclick="transferConfirm(<?php echo e($row->id); ?>)">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END: Transfer Room Inventory Modal -->

</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\Laravel\inventaris-iot\resources\views/data_inventaris.blade.php ENDPATH**/ ?>